import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;

public class PathDrawing extends JFrame {
    private BufferedImage image;
    private Point startPoint;
    private Point endPoint;
    private ArrayList<Line> lines = new ArrayList<>();
    private JRadioButton verticalButton;
    private JRadioButton horizontalButton;
    private Line selectedLine = null;
    private Point previousMousePoint = null;

    public PathDrawing(Main mainFrame) {
        setTitle("Path Drawing");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Load the image
        loadImage();

        // Panel for selecting vertical or horizontal lines
        JPanel directionPanel = new JPanel();
        verticalButton = new JRadioButton("Vertical", true);
        horizontalButton = new JRadioButton("Horizontal");
        ButtonGroup group = new ButtonGroup();
        group.add(verticalButton);
        group.add(horizontalButton);
        directionPanel.add(verticalButton);
        directionPanel.add(horizontalButton);
        add(directionPanel, BorderLayout.NORTH);

        // Panel for drawing
        JPanel drawPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (image != null) {
                    g.drawImage(image, 0, 0, null);
                }
                drawLines(g); // Draw lines
            }
        };

        // Add mouse listeners for line interaction
        drawPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (startPoint == null) {
                    startPoint = e.getPoint(); // Set start point
                } else if (endPoint == null) {
                    endPoint = e.getPoint(); // Set end point
                    generateLines(); // Generate the lines
                    drawPanel.repaint();
                } else {
                    // Check if any line is clicked for dragging
                    for (Line line : lines) {
                        if (line.contains(e.getPoint())) {
                            selectedLine = line;
                            previousMousePoint = e.getPoint();
                            break;
                        }
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                selectedLine = null; // Release the selected line
            }
        });

        drawPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (selectedLine != null) {
                    int dx = e.getX() - previousMousePoint.x;
                    int dy = e.getY() - previousMousePoint.y;

                    if (verticalButton.isSelected()) {
                        // Only adjust the X-axis for vertical lines
                        selectedLine.move(dx, 0);
                    } else if (horizontalButton.isSelected()) {
                        // Only adjust the Y-axis for horizontal lines
                        selectedLine.move(0, dy);
                    }

                    previousMousePoint = e.getPoint();
                    drawPanel.repaint(); // Repaint the panel
                }
            }
        });

        add(drawPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    // Method to load an image using JFileChooser
    private void loadImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Image");
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                image = ImageIO.read(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to generate grid lines between start and end points
    private void generateLines() {
        lines.clear();
        if (startPoint != null && endPoint != null) {
            int numberOfLines = 10; // Adjust the number of lines

            if (verticalButton.isSelected()) {
                double deltaX = (endPoint.getX() - startPoint.getX()) / numberOfLines;
                for (int i = 0; i <= numberOfLines; i++) {
                    int x = (int) (startPoint.getX() + deltaX * i);
                    lines.add(new Line(x, startPoint.y, x, endPoint.y));
                }
            } else if (horizontalButton.isSelected()) {
                double deltaY = (endPoint.getY() - startPoint.getY()) / numberOfLines;
                for (int i = 0; i <= numberOfLines; i++) {
                    int y = (int) (startPoint.getY() + deltaY * i);
                    lines.add(new Line(startPoint.x, y, endPoint.x, y));
                }
            }
        }
    }

    // Method to draw lines and points
    private void drawLines(Graphics g) {
        g.setColor(Color.RED); // Set color for lines
        for (Line line : lines) {
            g.drawLine(line.x1, line.y1, line.x2, line.y2);
        }

        // Draw start and end points
        if (startPoint != null) {
            g.setColor(Color.GREEN);
            g.fillOval(startPoint.x - 5, startPoint.y - 5, 10, 10);
            g.setColor(Color.BLACK);
            g.drawString("Start", startPoint.x + 10, startPoint.y);
        }
        if (endPoint != null) {
            g.setColor(Color.BLUE);
            g.fillOval(endPoint.x - 5, endPoint.y - 5, 10, 10);
            g.setColor(Color.BLACK);
            g.drawString("End", endPoint.x + 10, endPoint.y);
        }
    }

    // Line class to represent individual lines
    private static class Line {
        int x1, y1, x2, y2;

        Line(int x1, int y1, int x2, int y2) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        // Check if a point is near the line (with a small threshold)
        boolean contains(Point p) {
            int threshold = 5;
            return (Math.abs((y2 - y1) * p.x - (x2 - x1) * p.y + x2 * y1 - y2 * x1) /
                    Math.sqrt(Math.pow(y2 - y1, 2) + Math.pow(x2 - x1, 2))) < threshold;
        }

        // Move the line by a given delta
        void move(int dx, int dy) {
            this.x1 += dx;
            this.y1 += dy;
            this.x2 += dx;
            this.y2 += dy;
        }
    }

    public static void main(String[] args) {
        new PathDrawing(new Main()); // Assuming Main is your main class
    }
}